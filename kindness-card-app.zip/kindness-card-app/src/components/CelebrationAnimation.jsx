import React from "react";
import Confetti from "react-confetti";

const CelebrationAnimation = () => {
  return (
    <div className="celebration">
      <Confetti width={window.innerWidth} height={window.innerHeight} />
      <h2>🎉 Congratulations! 🎉</h2>
    </div>
  );
};

export default CelebrationAnimation;