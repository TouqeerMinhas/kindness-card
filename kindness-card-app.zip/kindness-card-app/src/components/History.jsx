import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";

const History = () => {
  const [history, setHistory] = useState([]);

  // Load history from local storage
  useEffect(() => {
    const savedHistory = JSON.parse(localStorage.getItem("kindnessHistory")) || [];
    setHistory(savedHistory);
  }, []);

  return (
    <motion.div
      className="history"
      initial={{ opacity: 0, x: -50 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h2>Task History</h2>
      <ul>
        {history.map((item, index) => (
          <motion.li
            key={index}
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <p>Task: {item.text}</p>
            <p>Status: {item.completed ? "Completed ✅" : "Uncompleted ❌"}</p>
            <p>Date: {item.date}</p>
          </motion.li>
        ))}
      </ul>
    </motion.div>
  );
};

export default History;