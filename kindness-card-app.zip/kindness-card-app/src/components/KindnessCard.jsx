import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";

const KindnessCard = ({ onTaskComplete, onNewTask }) => {
  const [task, setTask] = useState({ text: "", score: 0 });
  const [completed, setCompleted] = useState(false);
  const [date, setDate] = useState(new Date().toLocaleDateString());

  // Sample kindness tasks
  const tasks = [
    { text: "Compliment someone", score: 10 },
    { text: "Donate to a charity", score: 20 },
    { text: "Help a stranger", score: 15 },
    { text: "Write a thank-you note", score: 5 },
  ];

  // Generate a random task
  const generateTask = () => {
    const randomTask = tasks[Math.floor(Math.random() * tasks.length)];
    setTask(randomTask);
    setCompleted(false);
    setDate(new Date().toLocaleDateString());
    onNewTask(randomTask);
  };

  // Load a new task every 24 hours
  useEffect(() => {
    const lastTaskDate = localStorage.getItem("lastTaskDate");
    if (!lastTaskDate || lastTaskDate !== new Date().toLocaleDateString()) {
      generateTask();
      localStorage.setItem("lastTaskDate", new Date().toLocaleDateString());
    } else {
      const savedTask = JSON.parse(localStorage.getItem("currentTask"));
      if (savedTask) {
        setTask(savedTask);
        setCompleted(savedTask.completed);
        setDate(savedTask.date);
      }
    }
  }, []);

  // Handle task completion
  const handleComplete = () => {
    setCompleted(true);
    onTaskComplete(task);
  };

  return (
    <motion.div
      className="kindness-card"
      initial={{ opacity: 0, y: -50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h2>Your Kindness Task for Today</h2>
      <p className="task-text">{task.text}</p>
      <p className="task-date">Date: {date}</p>
      <div className="buttons">
        <motion.button
          onClick={handleComplete}
          disabled={completed}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          {completed ? "Completed 🎉" : "Mark as Complete"}
        </motion.button>
        <motion.button
          onClick={generateTask}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          Generate New Task
        </motion.button>
      </div>
    </motion.div>
  );
};

export default KindnessCard;