import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import KindnessCard from "./components/KindnessCard";
import History from "./components/History";
import CelebrationAnimation from "./components/CelebrationAnimation";
import "./App.css";

const App = () => {
  const [totalScore, setTotalScore] = useState(0);
  const [showCelebration, setShowCelebration] = useState(false);

  // Load total score from local storage
  useEffect(() => {
    const savedScore = localStorage.getItem("totalScore");
    if (savedScore) {
      setTotalScore(parseInt(savedScore));
    }
  }, []);

  // Handle task completion
  const handleTaskComplete = (task) => {
    setTotalScore((prevScore) => prevScore + task.score);
    localStorage.setItem("totalScore", totalScore + task.score);

    // Show celebration animation
    setShowCelebration(true);
    setTimeout(() => setShowCelebration(false), 3000);

    // Save task to history
    const history = JSON.parse(localStorage.getItem("kindnessHistory")) || [];
    history.push({ text: task.text, completed: true, date: new Date().toLocaleDateString() });
    localStorage.setItem("kindnessHistory", JSON.stringify(history));
  };

  // Handle new task generation
  const handleNewTask = (task) => {
    localStorage.setItem("currentTask", JSON.stringify({ ...task, completed: false, date: new Date().toLocaleDateString() }));
  };

  return (
    <Router>
      <div className="App">
        <nav>
          <Link to="/">Home</Link>
          <Link to="/history">History</Link>
        </nav>
        <Routes>
          <Route
            path="/"
            element={
              <>
                {showCelebration && <CelebrationAnimation />}
                <KindnessCard onTaskComplete={handleTaskComplete} onNewTask={handleNewTask} />
                <p className="total-score">Total Kindness Score: {totalScore}</p>
              </>
            }
          />
          <Route path="/history" element={<History />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;